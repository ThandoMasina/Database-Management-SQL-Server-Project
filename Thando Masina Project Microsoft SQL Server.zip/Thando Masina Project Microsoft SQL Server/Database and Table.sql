/*=============================================================
FileName: Database and Table.sql
Programmer: Thando Masina
Description: This file will create the database and tables with the necessary constraints.
=============================================================*/


Use Master
GO

--If this database exist, we will delete it first
IF EXISTS(SELECT name FROM master.dbo.sysdatabases
	       WHERE name = 'TPS2')
BEGIN
	DROP DATABASE TPS2
	PRINT 'The database has been deleted'
END

--Creating the database
CREATE DATABASE TPS2
ON Primary
	(
		NAME = 'TPS2_data',
		FILENAME = 'c:\sql2016\TPS2_data.mdf',
		SIZE = 5MB,
		FILEGROWTH = 10%
	)
LOG ON
	(
		NAME = 'TPS2_log',
		FILENAME = 'c:\sql2016\TPS2_log.ldf',
		SIZE = 5MB,
		FILEGROWTH = 10%
	)

GO

USE TPS2
GO

CREATE TABlE SUPPLIER
	(
		suppID INT IDENTITY Not Null,
		suppName VARCHAR(30) Not Null,
		contNumber VARCHAR(15) Not Null,
		emailAddress VARCHAR(30) Not Null,
		CONSTRAINT SuppID_PK PRIMARY KEY (suppID)
	)
GO

PRINT 'The SUPPLIER table have been created'
GO

CREATE TABLE FOODTYPE
	(
		foodTypeID INT IDENTITY Not Null,
		foodName VARCHAR(30) Not Null,
		expiryDate DATETIME Not Null,
		suppID INT Not Null,
		PRIMARY KEY (foodTypeID),
		CONSTRAINT SuppID_FK FOREIGN KEY (suppID) REFERENCES SUPPLIER (suppID),
		CONSTRAINT CheckExpiryDate CHECK (expiryDate <= GETDATE()) --Check to see if the expiry date is today or in the past
	)
GO

PRINT 'The FOODTYPES table have been created'
GO



CREATE TABLE ANIMALCATEGORY
	(
		animalCategoryID INT IDENTITY Not Null,
		unitMeasurement VARCHAR(10) Not Null,
		CONSTRAINT CheckUnit CHECK (unitMeasurement > 0),   --Checks if the user entered a value higher than 0
		PRIMARY KEY(animalCategoryID)
	)
GO


ALTER TABLE ANIMALCATEGORY

DROP
      CheckUnit

GO

PRINT 'The ANIMALCATEGORY table have been created'
GO

CREATE TABLE FOODTYPEANIMALCATEGORY
	(
		quantity INT Not NULL,
		foodTypeID INT Not NULL,
		animalCategoryID INT Not NULL,

		--Creating a composite primary key for an intersection table
		CONSTRAINT FoodtypeID_FK FOREIGN KEY (foodTypeID) REFERENCES FOODTYPE (foodTypeID),
		CONSTRAINT AnimalCategoryID_FK FOREIGN KEY (animalCategoryID) REFERENCES ANIMALCATEGORY (animalCategoryID),
		CONSTRAINT CheckQuantity CHECK (quantity > 0)    --Checks if the user entered a value higher than 0
	)
GO

PRINT 'The FOODTYPES table have been created'
GO

CREATE TABLE PETTYPES
	(
		petID INT IDENTITY Not Null,
		petNumber VARCHAR(15) Not Null,
		petType VARCHAR(15) Not Null,
		animalCategoryID INT Not Null,
		PRIMARY KEY(petID),
		CONSTRAINT AnimalCategoryPETTYPE_FK FOREIGN KEY (animalCategoryID) REFERENCES ANIMALCATEGORY (animalCategoryID) 
	)
GO

ALTER TABLE PETTYPES
ALTER COLUMN petNumber INT
GO


PRINT 'The PETTYPE table have been created'
GO


	