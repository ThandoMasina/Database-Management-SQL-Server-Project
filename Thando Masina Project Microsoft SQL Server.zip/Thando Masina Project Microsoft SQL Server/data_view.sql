USE TPS2
GO

CREATE VIEW	vw_ManufacturerDetails
AS
SELECT s.suppID, s.suppName, ft.foodName, ft.foodTypeID, SUM(fv.quantity) AS 'Total Food Produced'
FROM SUPPLIER as s
JOIN FOODTYPE ft
ON s.suppID, = ft.suppID
JOIN FOODTYPEANIMALCATEGORY fv
ON ft.foodTypeID = fv.foodTypeID

--GROUP BY SUPPLIERS.suppID, suppName

GROUP BY s.suppID, s.suppName, ft.foodName, ft.foodTypeID
GO

--Testing our view above
SELECT * 
FROM vw_ManufacturerDetails
GO


CREATE VIEW vw_PetsPerType
AS
SELECT PETTYPES.petType, SUM(PETTYPES.petNumber) AS 'Total number of pets', ANIMALCATEGORY.animalCategoryID AS 'PetPerType' --
FROM PETTYPES
JOIN ANIMALCATEGORY
ON PETTYPES.animalCategoryID = ANIMALCATEGORY.animalCategoryID
--GROUP BY PETTYPES.petType, petNumber

GROUP BY PETTYPES.petType, ANIMALCATEGORY.animalCategoryID
GO

--Testing our view above
SELECT *
FROM vw_PetsPerType
GO

CREATE VIEW vw_ExpiredFoodDetails
AS
SELECT s.suppName, s.contNumber, FOODTYPE.foodName, FOODTYPE.foodTypeID, FOODTYPE.expiryDate, SUM(FOODTYPEANIMALCATEGORY.quantity) AS 'Total Food Produced', ANIMALCATEGORY.unitMeasurement AS 'expiredFoodDetails'
FROM SUPPLIER as s
JOIN FOODTYPE
ON s.suppID = FOODTYPE.suppID
--ON s.expiryDate = FOODTYPES.foodTypeID
JOIN FOODTYPEANIMALCATEGORY
ON FOODTYPE.foodTypeID = FOODTYPEANIMALCATEGORY.foodTypeID
JOIN ANIMALCATEGORY
ON FOODTYPEANIMALCATEGORY.animalCategoryID = ANIMALCATEGORY.animalCategoryID
--ON s.unitMeasurement = ANIMALCATEGORY.animalCategoryID
--JOIN FOODTYPEANIMALCATEGORY
--ON FOODTYPEANIMALCATEGORY.foodTypeID = FOODTYPE.foodTypeID

GROUP BY s.suppName, s.contNumber, FOODTYPE.foodName, FOODTYPE.foodTypeID, FOODTYPE.expiryDate, ANIMALCATEGORY.unitMeasurement
GO

--Testing our view above
SELECT *
FROM vw_ExpiredFoodDetails
GO

CREATE VIEW vw_LowestFoods
AS
SELECT DISTINCT TOP 3 PETTYPES.petType, PETTYPES.petNumber AS 'LowestFoods'
FROM PETTYPES
--JOIN PETTYPES
--on PETTYPES.petID = PETTYPES.petType

ORDER BY 'LowestFoods' ASC
GO

--Testing our view above
SELECT *
FROM vw_LowestFoods
GO