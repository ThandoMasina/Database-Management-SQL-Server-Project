/*=================================================================== 
FileName: Sample_Data.sql
Programmer: Thando Masina
Description: This file will insert sample data into the database.
=====================================================================*/

USE TPS2
GO

INSERT INTO SUPPLIER(suppName,contNumber,emailAddress)
VALUES
		('Pick n Pay','0735678905','PicknPay@gmail.com' ),
		('Shoprite','0879087685','Shoprite@gmail.com'),
		('Dunns','0985764332','Dunns@gmail.com'),
		('1775Coffee','0985473945','1775Coffee@gmail.com'),
		('Checkers','0986754567','Checkers@gmail.com'),
		('Leisure','098657432','Leisure@gmail.com')
GO

--Please note that when inserting a foreign key value, it must be existing
INSERT INTO FOODTYPE(foodName,expiryDate,suppID)
VALUES
		('Milk','2022/07/08',1),
		('Beef','2022/06/10',2),
		('Mince','2021/01/01',3),
		('Catmore','2022/04/19',4),
		('Dogmore','2021/09/09',5),
		('Wheat','2022/01/29',6)
GO


INSERT INTO ANIMALCATEGORY(unitMeasurement)
VALUES
		('Litre'),
		('Kilogram'),
		('Kilogram'),
		('Milligram'),
		('Milligram'),
		('Kilogram')
GO


INSERT INTO FOODTYPEANIMALCATEGORY(quantity,foodTypeID,animalCategoryID)
VALUES
		(6,23,35),
		(30,24,36),
		(20,25,37),
		(200,26,38),
		(100,27,39),
		(105,28,40)
GO


INSERT INTO PETTYPES(petNumber,petType,animalCategoryID)
VALUES
		(10,'Mammal',35),
		(40,'Reptile',36),
		(50,'Avians',37),
		(70,'Mammal',38),
		(80,'Reptile',39),
		(93,'Mammal',40)
GO