USE TPS2
GO

--Deleting a customer
CREATE PROCEDURE sp_DeleteFoodTypes
@foodTypeID INT
AS
BEGIN
	
	--IF NOT EXISTS(SELECT 
	--		  FROM FOODTYPE
	--		  WHERE foodTypeID = @foodTypeID)
	--BEGIN
	--	RAISERROR('FOODTYPES %d does not exist!',16,1, @foodTypeID) 
	--	RETURN																
	--END

	--IF EXISTS(SELECT  --We can select anything when doing a validation as the returned value does not matter
	--	      FROM SUPPLIER as s
	--		  JOIN FOODTYPE 
	--		  ON FOODTYPE.suppID = s.suppID
	--	      WHERE FOODTYPE.suppID= @foodTypeID)
	--BEGIN
		--DELETE FROM FOODTYPE WHERE FOODTYPE.foodTypeID = @foodTypeID;
		DELETE FROM FOODTYPEANIMALCATEGORY WHERE FOODTYPEANIMALCATEGORY.foodTypeID = @foodTypeID;
		DELETE FROM FOODTYPE WHERE FOODTYPE.foodTypeID = @foodTypeID;
		--NNER JOIN FOODTYPEANIMALCATEGORY 
		--ON FOODTYPE.foodTypeID = FOODTYPEANIMALCATEGORY.foodTypeID
		
END
GO

	DELETE
	FROM FOODTYPE
	WHERE FOODTYPE.foodTypeID  = @foodTypeID 
END
GO

EXEC sp_DeleteFoodTypes 12 
GO

SELECT *
FROM FOODTYPE
GO


