USE TPS2 
GO

--Creating a nonclustered index on the Spares Description column
CREATE TRIGGER tr_supplier
ON SUPPLIER
AFTER INSERT
AS
	PRINT 'A new supplier record has been created'
GO

CREATE TRIGGER tr_FOODTYPE
ON FOODTYPE
AFTER INSERT
AS
	PRINT'A new foodtype record has been entered'
GO

