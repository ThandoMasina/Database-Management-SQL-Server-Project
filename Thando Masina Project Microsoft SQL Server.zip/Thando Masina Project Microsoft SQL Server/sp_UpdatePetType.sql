USE TPS2
GO


--CREATE PROCEDURE sp_UpdatePetType
	--@petID INT,
	--@petNumber VARCHAR(15),
	--@petType VARCHAR(15),
	--@animalCategoryID INT

--AS
--BEGIN

	/*IF NOT EXIST(SELECT 0
			FROM ANIMALCATEGORY
			WHERE animalCategoryID = @animalCategoryID
	BEGIN
		RAISERROR('The Pet ID %d does not exist!',16,1, @animalCategoryID)
		RETURN
	END

	IF NOT EXISTS(SELECT 1
				FROM PETTYPES
				WHERE petID = @petID
	BEGIN
		RAISERROR('The Pet ID %d does not exist!',16,1, @petID)
		RETURN
	END

	IF NOT EXISTS(SELECT 1
				FROM PETTYPES
				WHERE petNumber = @petNumber
	BEGIN
		RAISERROR('The Pet ID %d does not exist!',16,1, @petNumber)
		RETURN
	END

	IF NOT EXISTS(SELECT 0
				FROM PETTYPES
				WHERE petType = @petType
	BEGIN
		RAISERROR('The Pet ID %d does not exist!',16,1, @petType)
	END*/


--END
--GO

UPDATE PETTYPES
SET petNumber = 40
WHERE petID = 2
GO

EXEC sp_UpdatePetType 2,40,'Avians',36  --Correct
GO


SELECT *
FROM PETTYPES
GO