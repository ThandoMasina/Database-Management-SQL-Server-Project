USE TPS2
GO

--Creating a nonclustered index
CREATE INDEX idx_supplier
ON SUPPLIER
(
	suppID,
	suppName,
	contNumber,
	emailAddress
)
GO

--Create a nonclusted index on description column
CREATE INDEX idx_foodType
ON FOODTYPE
(
	foodTypeID,
	foodName,
	expiryDate,
	suppID
)
GO

CREATE INDEX idx_foodTypeAnimalCategory
ON FOODTYPEANIMALCATEGORY
(
	quantity,
	foodTypeID,
	animalCategoryID
)
GO

CREATE INDEX idx_animalCategory
ON ANIMALCATEGORY
(
	animalCategoryID,
	unitMeasurement
)
GO

CREATE INDEX idx_petTypes
ON PETTYPES
(
	petID,
	petNumber,
	petType,
	animalCategoryID
)
GO