USE TPS2
GO


--CREATE PROCEDURE sp_PettypeInsert
	--@petID INT,
	--@petNumber VARCHAR(15),
	--@petType VARCHAR(15),
	--@animalCategoryID INT

--AS
--BEGIN
	
	--IF (@animalCategoryID <0)
	--BEGIN
		--RAISERROR('petNumber can not be so low',16,1)
		--RETURN
	--END

	--IF (@petID  <0)
	--BEGIN
		--RAISERROR('petNumber can not be so low',16,1)
		--RETURN
	--END

	--IF (@petNumber <0)
	--BEGIN
		--RAISERROR('petNumber can not be so low',16,1)
		--RETURN
	--END

	--INSERT INTO PETTYPE(petID,petNumber,petType,animalCategoryID)
	--VALUES(@petID, @petNumber,@petType,@animalCategoryID)

--END
--GO


--EXEC sp_PettypeInsert 2,10,'Mammal',14     --Correct
INSERT INTO PETTYPES(petNumber,petType,animalCategoryID)
VALUES (78,'avians',20)
GO

