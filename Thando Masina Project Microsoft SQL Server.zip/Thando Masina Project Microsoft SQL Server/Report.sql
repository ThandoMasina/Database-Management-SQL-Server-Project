USE TPS2
GO

CREATE PROCEDURE sp_Report
	@suppID INT
AS
BEGIN

	DECLARE	@suppName VARCHAR(30)
	DECLARE @contNumber VARCHAR(15)
	DECLARE @emailAddress VARCHAR(30)
	DECLARE @expiryDate DATETIME
	DECLARE @foodTypeID INT
	DECLARE @foodName VARCHAR(30)
	


	DECLARE sp_Displaylaw Cursor
		FOR SELECT s.suppID, s.suppName, s.contNumber, s.emailAddress,FOODTYPE.expiryDate, FOODTYPE.foodTypeID, FOODTYPE.foodName 
			FROM SUPPLIER AS s
			JOIN FOODTYPE
			ON s.suppID =FOODTYPE.suppID
			WHERE s.suppID = @suppID	
		FOR READ ONLY
		--GROUP BY  s.suppName, s.contNumber, s.emailAddress,FOODTYPE.expiryDate, FOODTYPE.foodTypeID, FOODTYPE.foodName 
	

	OPEN sp_Displaylaw

		FETCH NEXT FROM sp_Displaylaw
			INTO @suppID, @suppName, @contNumber,@emailAddress,@expiryDate,@foodTypeID,@foodName

		WHILE @@FETCH_STATUS = 0
			FETCH NEXT FROM sp_Displaylaw
				INTO @suppID, @suppName, @contNumber,@emailAddress,@expiryDate,@foodTypeID,@foodName

				PRINT 'EXPIRED PRODUCTS REPORT:'
				PRINT '__________________________________________________'
				PRINT ''

				PRINT 'Generated: '
				PRINT   @expiryDate 
				PRINT ''

				PRINT 'Company ID: ' + CAST(@suppID AS VARCHAR)
				PRINT 'Company Name:' + @suppName
				PRINT 'Contact Number: ' +  @contNumber
				PRINT 'Email: ' + @emailAddress

				PRINT '__________________________________________________'
				PRINT 'Food ID Food Type'

				PRINT CAST(@foodTypeID AS VARCHAR) + SPACE(30 - LEN(@foodTypeID)) ++ @foodName + 
				SPACE(30 - LEN(@foodName))

				SELECT COUNT(suppID)
				from SUPPLIER
				PRINT '____________________ '
				PRINT 'Total Records:' + CAST(@suppID AS VARCHAR)
				PRINT '____________________ '
		
 

	CLOSE sp_Displaylaw
	DEALLOCATE sp_Displaylaw
END
